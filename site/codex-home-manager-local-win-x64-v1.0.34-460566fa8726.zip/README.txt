Codex Cockpit 1.0.34
Run Codex-Cockpit-Setup-x64.exe to install. This is not a portable application.
