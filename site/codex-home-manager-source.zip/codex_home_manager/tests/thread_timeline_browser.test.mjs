import assert from "node:assert/strict";
import path from "node:path";
import { pathToFileURL } from "node:url";
import { build } from "esbuild";

const projectRoot = path.resolve(import.meta.dirname, "..");
const bundle = await build({
  entryPoints: [path.join(projectRoot, "src", "threadTimeline.ts")],
  bundle: true,
  format: "esm",
  platform: "browser",
  write: false
});
const moduleUrl = `data:text/javascript;base64,${Buffer.from(bundle.outputFiles[0].contents).toString("base64")}`;
const { isVisibleCommentaryItem, isVisibleCommentaryRecord, timelineItemFromJson, readBrowserTimelineItem, readBrowserTimelinePage, scanBrowserTimelineSearchPages } = await import(moduleUrl);
const searchBundle = await build({
  entryPoints: [path.join(projectRoot, "src", "threadContentSearch.ts")],
  bundle: true,
  format: "esm",
  platform: "browser",
  write: false
});
const searchModuleUrl = `data:text/javascript;base64,${Buffer.from(searchBundle.outputFiles[0].contents).toString("base64")}`;
const { findSearchMatches, maxSearchMatchesPerText, normalizeSearchText } = await import(searchModuleUrl);

assert.equal(normalizeSearchText("ﬀ ﬃ ﭏ Straße Σς Cafe\u0301 İZMİR"), "ff ffi אל strasse σσ cafe izmir");
const unicodeSearchCases = [
  ["A ﬀ ligature", "ff", "ﬀ"],
  ["A ﬃ ligature", "ffi", "ﬃ"],
  ["Hebrew ﭏ ligature", "אל", "ﭏ"],
  ["Straße", "STRASSE", "Straße"],
  ["ΟΣ", "οσ", "ΟΣ"],
  ["ος", "ΟΣ", "ος"],
  ["Cafe\u0301", "CAFÉ", "Cafe\u0301"],
  ["İZMİR", "izmir", "İZMİR"]
];
for (const [source, query, expectedHighlight] of unicodeSearchCases) {
  const matches = findSearchMatches(source, query);
  assert.equal(matches.length, 1, `${JSON.stringify(query)} must match ${JSON.stringify(source)}`);
  assert.equal(source.slice(matches[0].start, matches[0].end), expectedHighlight);
}
const denseMatches = findSearchMatches("a".repeat(20_000), "a");
assert.equal(denseMatches.length, maxSearchMatchesPerText, "per-item highlighting must have a hard upper bound");
assert.deepEqual(denseMatches.at(-1), { start: maxSearchMatchesPerText - 1, end: maxSearchMatchesPerText });

const delegationText = '<codex_delegation>\n<source_thread_id>source-task</source_thread_id>\n<input>handover complete</input>\n</codex_delegation>';
const delegationRecord = { type: 'response_item', payload: { type: 'function_call_output', namespace: 'codex_app', name: 'send_message_to_thread', output: delegationText } };
const delegationMirror = { type: 'event_msg', payload: { type: 'item_completed', item: { ...delegationRecord.payload, type: 'FunctionCallOutput' } } };
assert.equal(timelineItemFromJson(delegationRecord, 1).promptSourceType, 'delegation');
assert.equal(timelineItemFromJson(delegationRecord, 1).hasPureText, false);
assert.equal(timelineItemFromJson(delegationMirror, 2), null);
for (const replacement of [{ namespace: 'other' }, { name: 'read_thread' }, { output: '{"threadId":"target"}' }, { output: `quoted ${delegationText}` }]) {
  assert.equal(timelineItemFromJson({ ...delegationRecord, payload: { ...delegationRecord.payload, ...replacement } }, 1).promptSourceType, '');
}
const delegationFile = new File([[delegationRecord, delegationMirror, delegationRecord].map(JSON.stringify).join('\n') + '\n'], 'delegation.jsonl');
const delegationPage = await readBrowserTimelinePage(delegationFile, 'thread-1', 'Fixture', 'delegation.jsonl', { sourceFilter: 'delegation', kind: 'conversation' });
assert.equal(delegationPage.items.length, 2);
for (const kind of ['conversation', 'user', 'all']) {
  for (const sourceFilter of ['all', 'delegation']) {
    const page = await readBrowserTimelinePage(delegationFile, 'thread-1', 'Fixture', 'delegation.jsonl', { sourceFilter, kind, search: 'handover' });
    assert.equal(page.items.length, 2, `${kind} + ${sourceFilter} must retain incoming messages`);
  }
}
assert.equal((await readBrowserTimelinePage(delegationFile, 'thread-1', 'Fixture', 'delegation.jsonl', { sourceFilter: 'pure', kind: 'conversation' })).items.length, 0);

const commentary = timelineItemFromJson({
  type: "response_item",
  timestamp: "2026-08-13T01:00:00Z",
  payload: {
    type: "message",
    role: "assistant",
    phase: "commentary",
    content: [{ type: "output_text", text: "正在核对真实页面" }]
  }
}, 1);
assert.equal(commentary.kind, "commentary");
assert.equal(commentary.label, "进度说明");
assert.equal(isVisibleCommentaryRecord({
  type: "event_msg",
  payload: { type: "agent_message", phase: "commentary", message: "正在检查阶段结果" }
}), true);

const nonCommentaryRecords = [
  { type: "event_msg", payload: { type: "exec_command_begin", phase: "commentary", command: "npm test" } },
  { type: "event_msg", payload: { type: "patch_apply_begin", phase: "commentary", patch: "*** Begin Patch" } },
  { type: "event_msg", payload: { type: "agent_reasoning", phase: "commentary", text: "内部推理" } },
  { type: "response_item", payload: { type: "custom_tool_call", phase: "commentary", call_id: "tool-1", name: "shell", input: "dir" } },
  { type: "response_item", payload: { type: "custom_tool_call_output", phase: "commentary", call_id: "tool-1", output: "command output" } },
  { type: "response_item", payload: { type: "reasoning", phase: "commentary", encrypted_content: "opaque" } },
  { type: "response_item", payload: { type: "message", role: "developer", phase: "commentary", content: [{ type: "input_text", text: "developer context" }] } }
];
for (const [index, record] of nonCommentaryRecords.entries()) {
  assert.equal(isVisibleCommentaryRecord(record), false, `record ${index} must not enter visible commentary`);
  assert.notEqual(timelineItemFromJson(record, 100 + index)?.kind, "commentary");
}
assert.equal(isVisibleCommentaryItem({ ...commentary, payloadType: "custom_tool_call_output" }), false);

const filterRecords = [
  { type: "response_item", payload: { type: "message", role: "user", content: [{ type: "input_text", text: "用户问题" }] } },
  { type: "response_item", payload: { type: "message", role: "assistant", phase: "commentary", content: [{ type: "output_text", text: "正在核对数据来源" }] } },
  { type: "event_msg", payload: { type: "agent_message", message: "正在核对数据来源" } },
  { type: "event_msg", payload: { type: "agent_message", phase: "commentary", message: "数据来源已确认，继续验证" } },
  { type: "event_msg", payload: { type: "exec_command_begin", phase: "commentary", command: "python verify.py" } },
  { type: "event_msg", payload: { type: "patch_apply_begin", phase: "commentary", patch: "*** Begin Patch" } },
  { type: "response_item", payload: { type: "reasoning", summary: [{ type: "summary_text", text: "不可进入主要内容的推理" }], encrypted_content: "opaque" } },
  { type: "response_item", payload: { type: "custom_tool_call_output", phase: "commentary", call_id: "tool-2", output: "不可进入思考过程的工具输出" } },
  { type: "response_item", payload: { type: "message", role: "assistant", phase: "final", content: [{ type: "output_text", text: "最终结论" }] } },
  { type: "event_msg", payload: { type: "agent_message", message: "最终结论" } }
];
const filterFile = new File([`${filterRecords.map((record) => JSON.stringify(record)).join("\n")}\n`], "filters.jsonl", { type: "application/jsonl" });
const mainContentPage = await readBrowserTimelinePage(filterFile, "thread-filter", "Filter", "filters.jsonl", { kind: "conversation" });
assert.deepEqual(mainContentPage.items.map((item) => [item.kind, item.text]), [
  ["user", "用户问题"],
  ["commentary", "正在核对数据来源"],
  ["commentary", "数据来源已确认，继续验证"],
  ["assistant", "最终结论"]
]);
const commentaryPage = await readBrowserTimelinePage(filterFile, "thread-filter", "Filter", "filters.jsonl", { kind: "commentary" });
assert.deepEqual(commentaryPage.items.map((item) => item.text), ["正在核对数据来源", "数据来源已确认，继续验证"]);
assert.doesNotMatch(commentaryPage.items.map((item) => item.text).join("\n"), /python verify|Begin Patch|工具输出|推理/);

const automationFile = new File([`${[
  { type: "response_item", payload: { type: "message", role: "user", content: [{ type: "input_text", text: "<heartbeat><instructions>巡检插件</instructions></heartbeat>" }] } },
  { type: "response_item", payload: { type: "message", role: "user", content: [{ type: "input_text", text: "普通用户输入" }] } }
].map((record) => JSON.stringify(record)).join("\n")}\n`], "automation.jsonl", { type: "application/jsonl" });
const automationPage = await readBrowserTimelinePage(automationFile, "thread-automation", "Automation", "automation.jsonl", {
  kind: "conversation",
  sourceFilter: "automation"
});
assert.deepEqual(automationPage.items.map((item) => [item.kind, item.promptSourceType, item.text]), [
  ["context", "automation", "<heartbeat><instructions>巡检插件</instructions></heartbeat>"]
]);

const attachmentFile = new File([`${[
  { type: "response_item", payload: { type: "message", role: "user", content: [{ type: "input_text", text: "# Files mentioned by the user:\n\n## secret-file.txt: C:/Temp/secret-file.txt\n\n## My request for Codex:\n请只显示附件里的正文" }] } }
].map((record) => JSON.stringify(record)).join("\n")}\n`], "attachment.jsonl", { type: "application/jsonl" });
const attachmentFocusedPage = await readBrowserTimelinePage(attachmentFile, "thread-attachment", "Attachment", "attachment.jsonl", {
  kind: "user",
  sourceFilter: "focused"
});
assert.deepEqual(attachmentFocusedPage.items.map((item) => item.text), ["请只显示附件里的正文"]);
const attachmentPurePage = await readBrowserTimelinePage(attachmentFile, "thread-attachment", "Attachment", "attachment.jsonl", {
  kind: "user",
  sourceFilter: "pure"
});
assert.deepEqual(attachmentPurePage.items.map((item) => item.text), ["请只显示附件里的正文"]);
const attachmentContextPage = await readBrowserTimelinePage(attachmentFile, "thread-attachment", "Attachment", "attachment.jsonl", {
  kind: "user",
  sourceFilter: "with_agents"
});
assert.match(attachmentContextPage.items[0].text, /secret-file\.txt/);

const userMirrorBoundaryFile = new File([`${[
  { type: "response_item", payload: { type: "message", role: "user", content: [{ type: "input_text", text: "相同文本" }] } },
  { type: "event_msg", payload: { type: "agent_message", message: "相同文本" } }
].map((record) => JSON.stringify(record)).join("\n")}\n`], "user-mirror-boundary.jsonl", { type: "application/jsonl" });
const userMirrorBoundaryPage = await readBrowserTimelinePage(userMirrorBoundaryFile, "thread-user-mirror-boundary", "User mirror boundary", "user-mirror-boundary.jsonl", { kind: "conversation" });
assert.deepEqual(userMirrorBoundaryPage.items.map((item) => [item.kind, item.text]), [
  ["user", "相同文本"],
  ["assistant_unclassified", "相同文本"]
]);

const mirrorLoadRecords = [];
for (let index = 0; index < 80; index += 1) {
  const text = `阶段进度 ${index} ${"x".repeat(6_000)}`;
  mirrorLoadRecords.push(
    { type: "response_item", payload: { type: "message", role: "assistant", phase: "commentary", content: [{ type: "output_text", text }] } },
    { type: "event_msg", payload: { type: "agent_message", message: text } }
  );
}
const mirrorLoadFile = new File([`${mirrorLoadRecords.map((record) => JSON.stringify(record)).join("\n")}\n`], "mirror-load.jsonl", { type: "application/jsonl" });
const originalMirrorSlice = mirrorLoadFile.slice.bind(mirrorLoadFile);
let mirrorSliceCount = 0;
let mirrorBytesRead = 0;
mirrorLoadFile.slice = (start, end, contentType) => {
  mirrorSliceCount += 1;
  mirrorBytesRead += (end ?? mirrorLoadFile.size) - (start ?? 0);
  return originalMirrorSlice(start, end, contentType);
};
const mirrorLoadPage = await readBrowserTimelinePage(mirrorLoadFile, "thread-mirror-load", "Mirror load", "mirror-load.jsonl", { kind: "commentary", limit: 200 });
assert.equal(mirrorLoadPage.items.length, 80);
assert.ok(mirrorSliceCount <= 6, `single-pass mirror normalization used ${mirrorSliceCount} slices`);
assert.ok(mirrorBytesRead <= mirrorLoadFile.size * 3, `single-pass mirror normalization read ${mirrorBytesRead} bytes for ${mirrorLoadFile.size}-byte input`);

const eventReasoning = timelineItemFromJson({
  type: "event_msg",
  payload: { type: "agent_reasoning", text: "持久化推理内容" }
}, 11);
assert.equal(eventReasoning.kind, "reasoning");
assert.equal(eventReasoning.label, "推理记录");

const toolSearch = timelineItemFromJson({
  type: "response_item",
  payload: { type: "tool_search_call", call_id: "search-1", query: "thread tools" }
}, 2);
assert.equal(toolSearch.kind, "tool_call");
assert.match(toolSearch.text, /thread tools/);

const redacted = timelineItemFromJson({
  type: "response_item",
  payload: {
    type: "custom_tool_call_output",
    call_id: "image-1",
    output: "preview=data:image/png;base64,PRIVATE_BYTES_123456"
  }
}, 3);
assert.doesNotMatch(redacted.text, /PRIVATE_BYTES/);
assert.match(redacted.text, /附件内容已隐藏/);

const shortDataUrl = timelineItemFromJson({
  type: "response_item",
  payload: { type: "custom_tool_call_output", call_id: "short-image", output: "preview=data:image/png;base64,YQ==" }
}, 31);
assert.doesNotMatch(shortDataUrl.text, /YQ==/);
assert.match(shortDataUrl.text, /附件内容已隐藏/);

const mixedReasoning = timelineItemFromJson({
  type: "response_item",
  payload: {
    type: "reasoning",
    summary: [{ type: "summary_text", text: "可读摘要" }],
    encrypted_content: "opaque"
  }
}, 4);
assert.equal(mixedReasoning.text, "可读摘要");
assert.equal(mixedReasoning.label, "推理记录");
assert.equal(mixedReasoning.encrypted, false);
assert.equal(mixedReasoning.hasEncryptedContent, true);

const encryptedReasoning = timelineItemFromJson({
  type: "response_item",
  payload: { type: "reasoning", encrypted_content: "opaque" }
}, 5);
assert.equal(encryptedReasoning.label, "推理记录");
assert.equal(encryptedReasoning.text, "");
assert.equal(encryptedReasoning.encrypted, true);
assert.equal(encryptedReasoning.readable, false);
assert.doesNotMatch(
  [eventReasoning.label, mixedReasoning.label, encryptedReasoning.label].join("\n"),
  /推理摘要|加密推理记录/
);

const oversizedLine = JSON.stringify({
  type: "response_item",
  payload: {
    type: "message",
    role: "user",
    content: [
      { type: "input_text", text: "超大记录中的用户正文必须恢复" },
      { type: "input_image", image_url: `data:image/png;base64,${"x".repeat(9 * 1024 * 1024)}` }
    ]
  }
});
const oversizedAssistantLine = JSON.stringify({
  type: "response_item",
  payload: {
    type: "message",
    role: "assistant",
    phase: "final",
    content: [
      { type: "output_text", text: "超大记录中的助手正文必须恢复" },
      { type: "output_image", image_url: `data:image/png;base64,${"y".repeat(9 * 1024 * 1024)}` }
    ]
  }
});
const oversizedCommentaryLine = JSON.stringify({
  type: "response_item",
  payload: {
    type: "message",
    role: "assistant",
    phase: "commentary",
    content: [
      { type: "output_text", text: "超大记录中的 commentary 正文必须恢复" },
      { type: "output_image", image_url: `data:image/png;base64,${"z".repeat(9 * 1024 * 1024)}` }
    ]
  }
});
const visibleLine = JSON.stringify({
  type: "event_msg",
  payload: { type: "agent_message", phase: "commentary", message: "安全读取" }
});
const sourceFile = new File([`${oversizedLine}\n${oversizedAssistantLine}\n${oversizedCommentaryLine}\n${visibleLine}\n`], "rollout.jsonl", { type: "application/jsonl" });
const originalSlice = sourceFile.slice.bind(sourceFile);
sourceFile.slice = (start, end, contentType) => {
  assert.ok((end ?? sourceFile.size) - (start ?? 0) <= 8 * 1024 * 1024, "reader must not allocate an oversized line");
  return originalSlice(start, end, contentType);
};
const page = await readBrowserTimelinePage(sourceFile, "thread-1", "Thread", "rollout.jsonl", { kind: "all" });
assert.deepEqual(page.items.map((item) => item.text), [
  "超大记录中的用户正文必须恢复\n[图片附件]",
  "超大记录中的助手正文必须恢复\n[图片附件]",
  "超大记录中的 commentary 正文必须恢复\n[图片附件]",
  "安全读取"
]);
assert.doesNotMatch(page.items.map((item) => item.text).join("\n"), /data:image|[xyz]{100}/);
assert.equal(page.skippedOversizedRecords, 0);
assert.equal(page.recoveredOversizedRecords, 3);
assert.equal(page.hasMore, false);
assert.equal(page.nextBeforeByte, null);
const recoveredItem = await readBrowserTimelineItem(sourceFile, 0);
assert.match(recoveredItem.text, /超大记录中的用户正文必须恢复/);
assert.doesNotMatch(recoveredItem.text, /data:image|x{100}/);

const virtualSize = 1_400_000_000;
let virtualBytesRead = 0;
const virtualFile = {
  size: virtualSize,
  slice(start = 0, end = virtualSize) {
    const length = end - start;
    virtualBytesRead += length;
    return new Blob([new Uint8Array(length).fill(120)]);
  }
};
const virtualPage = await readBrowserTimelinePage(virtualFile, "thread-virtual", "Virtual", "virtual.jsonl", { kind: "all" });
assert.equal(virtualPage.items.length, 0);
assert.equal(virtualPage.skippedOversizedRecords, 1);
assert.equal(virtualPage.hasMore, true);
assert.equal(virtualPage.nextBeforeByte, virtualSize - (64 * 1024 * 1024));
assert.ok(virtualBytesRead <= (64 * 1024 * 1024) + 1, `virtual reader read ${virtualBytesRead} bytes`);

function userMessageLine(text) {
  return JSON.stringify({
    type: "response_item",
    payload: { type: "message", role: "user", content: [{ type: "input_text", text }] }
  });
}

async function assertAutomaticBudgetContinuation({ file, query, expectedBudget }) {
  const progress = [];
  const cursors = [];
  const result = await scanBrowserTimelineSearchPages(
    async (beforeByte) => {
      cursors.push(beforeByte);
      return readBrowserTimelinePage(file, `thread-${expectedBudget}`, "Budget", `${expectedBudget}.jsonl`, {
        beforeByte,
        kind: "all",
        search: query
      });
    },
    {
      onProgress: (pageResult) => progress.push({
        itemCount: pageResult.items.length,
        nextBeforeByte: pageResult.nextBeforeByte,
        scanLimited: pageResult.scanLimited,
        scannedBytes: pageResult.scannedBytes,
        scannedRecords: pageResult.scannedRecords
      })
    }
  );
  assert.ok(progress.length >= 2, `${expectedBudget} scan must continue to another page`);
  assert.deepEqual(progress[0].itemCount, 0, `${expectedBudget} first partial page must retain a truthful zero match count`);
  assert.equal(progress[0].scanLimited, true, `${expectedBudget} first partial page must be marked incomplete`);
  assert.ok(progress[0].nextBeforeByte > 0, `${expectedBudget} first partial page must expose nextBeforeByte`);
  assert.equal(cursors[0], null);
  for (let index = 1; index < cursors.length; index += 1) {
    assert.ok(cursors[index] < (cursors[index - 1] ?? file.size), `${expectedBudget} cursors must decrease monotonically`);
  }
  assert.equal(result.scanLimited, false, `${expectedBudget} final page must be complete`);
  assert.equal(result.hasMore, false, `${expectedBudget} scan must reach the beginning of the file`);
  assert.deepEqual(result.items.map((item) => item.text), [query]);
}

const recordBudgetTarget = "record-budget-target";
const recordBudgetFile = new File([
  `${userMessageLine(recordBudgetTarget)}\n`,
  `${userMessageLine("ordinary record without the target")}\n`.repeat(10_005)
], "record-budget.jsonl", { type: "application/jsonl" });
await assertAutomaticBudgetContinuation({ file: recordBudgetFile, query: recordBudgetTarget, expectedBudget: "record" });

const byteBudgetTarget = "byte-budget-target";
const byteBudgetFile = new File([
  `${userMessageLine(byteBudgetTarget)}\n`,
  `${userMessageLine("x".repeat(4_096))}\n`.repeat(8_250)
], "byte-budget.jsonl", { type: "application/jsonl" });
await assertAutomaticBudgetContinuation({ file: byteBudgetFile, query: byteBudgetTarget, expectedBudget: "byte" });

console.log("thread timeline browser tests passed");
