import assert from "node:assert/strict";
import path from "node:path";
import { build } from "esbuild";

const projectRoot = path.resolve(import.meta.dirname, "..");
const bundle = await build({
  entryPoints: [path.join(projectRoot, "src", "browserHome.ts")],
  bundle: true,
  format: "esm",
  platform: "browser",
  write: false,
  plugins: [{
    name: "browser-home-test-stubs",
    setup(buildApi) {
      buildApi.onResolve({ filter: /^sql\.js$/ }, () => ({ path: "sql.js", namespace: "stub" }));
      buildApi.onResolve({ filter: /sql-wasm\.wasm\?url$/ }, () => ({ path: "sql-wasm", namespace: "stub" }));
      buildApi.onLoad({ filter: /.*/, namespace: "stub" }, (args) => ({
        contents: args.path === "sql.js"
          ? "export default async function initSqlJs() { throw new Error('not used in streaming test'); }"
          : "export default 'sql-wasm-test-url';",
        loader: "js"
      }));
    }
  }]
});
const moduleUrl = `data:text/javascript;base64,${Buffer.from(bundle.outputFiles[0].contents).toString("base64")}`;
const {
  readBrowserThreadDailyTokenUsage,
  readBrowserThreadDetail,
  readBrowserThreadLogs,
  readBrowserThreadPrompts
} = await import(moduleUrl);

const records = [
  { type: "session_meta", timestamp: "2026-08-12T00:00:00Z", payload: { id: "thread-stream", cwd: "C:\\work" } },
  { type: "response_item", timestamp: "2026-08-12T01:00:00Z", payload: { type: "message", role: "user", content: [{ type: "input_text", text: "streamed user prompt" }] } },
  { type: "event_msg", timestamp: "2026-08-12T02:00:00Z", payload: { type: "token_count", info: { total_token_usage: { total_tokens: 100 } } } },
  { type: "event_msg", timestamp: "2026-08-13T02:00:00Z", payload: { type: "token_count", info: { total_token_usage: { total_tokens: 160 } } } },
  { type: "event_msg", timestamp: "2026-08-13T03:00:00Z", payload: { type: "agent_message", message: "needle-log" } }
];
for (let index = 0; index < 60; index += 1) {
  records.push({ type: "event_msg", timestamp: "2026-08-13T04:00:00Z", payload: { type: "status", message: `${index}:${"x".repeat(50_000)}` } });
}
const sourceFile = new File([records.map((record) => JSON.stringify(record)).join("\n") + "\n"], "rollout.jsonl", { type: "application/jsonl" });
sourceFile.text = async () => { throw new Error("whole-file text() must not be used"); };
const originalSlice = sourceFile.slice.bind(sourceFile);
let largestSlice = 0;
sourceFile.slice = (start = 0, end = sourceFile.size, contentType) => {
  largestSlice = Math.max(largestSlice, end - start);
  assert.ok(end - start <= 512 * 1024, `slice exceeded streaming boundary: ${end - start}`);
  return originalSlice(start, end, contentType);
};

const threadFile = { relativePath: "sessions/rollout-thread-stream.jsonl", archivedStore: false, handle: { getFile: async () => sourceFile } };
const workspace = {
  mode: "browser_folder",
  snapshot: { threads: [{ id: "thread-stream", title: "Streaming", tokensUsed: 160 }] },
  threadFiles: new Map([["thread-stream", threadFile]])
};

const detail = await readBrowserThreadDetail(workspace, "thread-stream");
assert.equal(detail.rolloutStats.lineCount, records.length);
assert.equal(detail.rolloutStats.aggregationExact, true);

const daily = await readBrowserThreadDailyTokenUsage(workspace, "thread-stream");
assert.equal(daily.summary.totalTokens, 160);
assert.equal(daily.summary.unknownTokenThreads, 0);
assert.equal(daily.summary.aggregationExact, true);

const logs = await readBrowserThreadLogs(workspace, "thread-stream", 0, 20, "all", "needle-log");
assert.equal(logs.matchedEntries, 1);
assert.equal(logs.entries[0].message, "needle-log");
assert.equal(logs.aggregationExact, true);

const prompts = await readBrowserThreadPrompts(workspace, "thread-stream");
assert.equal(prompts.promptCount, 1);
assert.equal(prompts.prompts[0].text, "streamed user prompt");
assert.equal(prompts.aggregationExact, true);
assert.equal(largestSlice, 512 * 1024);

console.log("browser home streaming tests passed");
