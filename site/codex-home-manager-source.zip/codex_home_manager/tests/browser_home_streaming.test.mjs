import assert from "node:assert/strict";
import fs from "node:fs/promises";
import path from "node:path";
import { build } from "esbuild";

const projectRoot = path.resolve(import.meta.dirname, "..");
const browserHomeSource = await fs.readFile(path.join(projectRoot, "src", "browserHome.ts"), "utf8");
const snapshotBuilderSource = browserHomeSource.slice(
  browserHomeSource.indexOf("async function buildBrowserThreadsFromSqlite"),
  browserHomeSource.indexOf("function emptyRolloutDisplayIntegrity")
);
assert.ok(snapshotBuilderSource.length > 1_000, "browser SQLite snapshot builder must be located");
assert.doesNotMatch(
  snapshotBuilderSource,
  /readBrowserRolloutThreadTitleUpdate/,
  "initial browser-folder listing must not scan rollout contents for title updates"
);
const bundle = await build({
  entryPoints: [path.join(projectRoot, "src", "browserHome.ts")],
  bundle: true,
  format: "esm",
  platform: "browser",
  write: false,
  plugins: [{
    name: "browser-home-test-stubs",
    setup(buildApi) {
      buildApi.onResolve({ filter: /^sql\.js$/ }, () => ({ path: "sql.js", namespace: "stub" }));
      buildApi.onResolve({ filter: /sql-wasm\.wasm\?url$/ }, () => ({ path: "sql-wasm", namespace: "stub" }));
      buildApi.onLoad({ filter: /.*/, namespace: "stub" }, (args) => ({
        contents: args.path === "sql.js"
          ? "export default async function initSqlJs() { throw new Error('not used in streaming test'); }"
          : "export default 'sql-wasm-test-url';",
        loader: "js"
      }));
    }
  }]
});
const moduleUrl = `data:text/javascript;base64,${Buffer.from(bundle.outputFiles[0].contents).toString("base64")}`;
const {
  exportBrowserThreadPrompts,
  readBrowserThreadDailyTokenUsage,
  readBrowserThreadDetail,
  readBrowserThreadLogs,
  readBrowserThreadPromptContext,
  readBrowserThreadPrompts
} = await import(moduleUrl);

const records = [
  { type: "session_meta", timestamp: "2026-08-12T00:00:00Z", payload: { id: "thread-stream", cwd: "C:\\work" } },
  { type: "response_item", timestamp: "2026-08-12T01:00:00Z", payload: { type: "message", role: "user", content: [{ type: "input_text", text: "streamed user prompt" }] } },
  { type: "event_msg", timestamp: "2026-08-12T02:00:00Z", payload: { type: "token_count", info: { total_token_usage: { total_tokens: 100 } } } },
  { type: "event_msg", timestamp: "2026-08-13T02:00:00Z", payload: { type: "token_count", info: { total_token_usage: { total_tokens: 160 } } } },
  { type: "event_msg", timestamp: "2026-08-13T03:00:00Z", payload: { type: "agent_message", message: "needle-log" } }
];
for (let index = 0; index < 60; index += 1) {
  records.push({ type: "event_msg", timestamp: "2026-08-13T04:00:00Z", payload: { type: "status", message: `${index}:${"x".repeat(50_000)}` } });
}
const sourceFile = new File([records.map((record) => JSON.stringify(record)).join("\n") + "\n"], "rollout.jsonl", { type: "application/jsonl" });
sourceFile.text = async () => { throw new Error("whole-file text() must not be used"); };
const originalSlice = sourceFile.slice.bind(sourceFile);
let largestSlice = 0;
sourceFile.slice = (start = 0, end = sourceFile.size, contentType) => {
  largestSlice = Math.max(largestSlice, end - start);
  assert.ok(end - start <= 512 * 1024, `slice exceeded streaming boundary: ${end - start}`);
  return originalSlice(start, end, contentType);
};

const threadFile = { relativePath: "sessions/rollout-thread-stream.jsonl", archivedStore: false, handle: { getFile: async () => sourceFile } };
const workspace = {
  mode: "browser_folder",
  snapshot: { threads: [{ id: "thread-stream", title: "Streaming", tokensUsed: 160 }] },
  threadFiles: new Map([["thread-stream", threadFile]])
};

const detail = await readBrowserThreadDetail(workspace, "thread-stream");
assert.equal(detail.rolloutStats.lineCount, records.length);
assert.equal(detail.rolloutStats.aggregationExact, true);

const daily = await readBrowserThreadDailyTokenUsage(workspace, "thread-stream");
assert.equal(daily.summary.totalTokens, 160);
assert.equal(daily.summary.unknownTokenThreads, 0);
assert.equal(daily.summary.aggregationExact, true);

const logs = await readBrowserThreadLogs(workspace, "thread-stream", 0, 20, "all", "needle-log");
assert.equal(logs.matchedEntries, 1);
assert.equal(logs.entries[0].message, "needle-log");
assert.equal(logs.aggregationExact, true);

const prompts = await readBrowserThreadPrompts(workspace, "thread-stream");
assert.equal(prompts.promptCount, 1);
assert.equal(prompts.prompts[0].text, "streamed user prompt");
assert.equal(prompts.aggregationExact, true);
assert.equal(largestSlice, 512 * 1024);

let downloadedPromptBlob = null;
let downloadedPromptFilename = "";
const originalDocument = globalThis.document;
const originalCreateObjectUrl = URL.createObjectURL;
const originalRevokeObjectUrl = URL.revokeObjectURL;
URL.createObjectURL = (blob) => {
  downloadedPromptBlob = blob;
  return "blob:browser-prompt-export";
};
URL.revokeObjectURL = () => {};
globalThis.document = {
  body: { appendChild() {} },
  createElement: () => ({
    href: "",
    set download(value) { downloadedPromptFilename = value; },
    click() {},
    remove() {}
  })
};
try {
  const browserExport = await exportBrowserThreadPrompts(workspace, "thread-stream");
  assert.equal(browserExport.promptCount, 1);
  assert.equal(downloadedPromptFilename, "codex-thread-prompts-thread-stream.md");
  assert.match(await downloadedPromptBlob.text(), /streamed user prompt/);
} finally {
  globalThis.document = originalDocument;
  URL.createObjectURL = originalCreateObjectUrl;
  URL.revokeObjectURL = originalRevokeObjectUrl;
}

function promptWorkspace(threadId, file) {
  return {
    mode: "browser_folder",
    snapshot: { threads: [{ id: threadId, title: "Prompt protocols" }] },
    threadFiles: new Map([[threadId, {
      relativePath: `sessions/rollout-${threadId}.jsonl`,
      archivedStore: false,
      handle: { getFile: async () => file }
    }]])
  };
}

function jsonlFile(records, filename) {
  return boundedPromptFile([records.map((record) => JSON.stringify(record)).join("\n") + "\n"], filename);
}

function boundedPromptFile(parts, filename) {
  const file = new File(parts, filename, {
    type: "application/jsonl"
  });
  file.text = async () => { throw new Error("whole-file text() must not be used"); };
  file.arrayBuffer = async () => { throw new Error("whole-file arrayBuffer() must not be used"); };
  const slice = file.slice.bind(file);
  file.slice = (start = 0, end = file.size, contentType) => {
    assert.ok(end - start <= 512 * 1024, `slice exceeded streaming boundary: ${end - start}`);
    return slice(start, end, contentType);
  };
  return file;
}

const protocolRecords = [
  {
    type: "user_message",
    timestamp: "2026-08-13T05:00:00.000Z",
    payload: { content: [{ type: "text", text: "mirrored user input" }] }
  },
  {
    type: "response_item",
    timestamp: "2026-08-13T05:00:01.000Z",
    payload: { type: "message", role: "user", content: [{ type: "input_text", text: "mirrored user input" }] }
  },
  {
    type: "event_msg",
    timestamp: "2026-08-13T05:00:02.000Z",
    payload: { type: "user_message", message: "mirrored user input" }
  },
  {
    type: "event_msg",
    timestamp: "2026-08-13T05:01:00.000Z",
    payload: { type: "user_message", message: "legacy event-only input" }
  },
  {
    type: "user_message",
    timestamp: "2026-08-13T05:01:30.000Z",
    payload: "top-level string payload"
  },
  {
    type: "response_item",
    timestamp: "2026-08-13T05:02:00.000Z",
    payload: { type: "message", role: "user", content: [{ type: "input_text", text: "intentionally repeated input" }] }
  },
  {
    type: "response_item",
    timestamp: "2026-08-13T05:03:00.000Z",
    payload: { type: "message", role: "user", content: [{ type: "input_text", text: "intentionally repeated input" }] }
  },
  {
    type: "user_message",
    timestamp: "2026-08-13T05:03:10.000Z",
    payload: { text: "same text sent again later" }
  },
  {
    type: "event_msg",
    timestamp: "2026-08-13T05:03:20.000Z",
    payload: { type: "user_message", message: "same text sent again later" }
  },
  {
    type: "user_message",
    timestamp: "2026-08-13T05:04:00.000Z",
    payload: { text: "<heartbeat>\n<automation_id>nightly</automation_id>\n<instructions>run check</instructions>\n</heartbeat>" }
  },
  {
    type: "response_item",
    timestamp: "2026-08-13T05:05:00.000Z",
    payload: { type: "message", role: "user", content: [{ type: "input_text", text: "<codex_delegation>\n<input>forwarded work</input>\n</codex_delegation>" }] }
  },
  {
    type: "event_msg",
    timestamp: "2026-08-13T05:06:00.000Z",
    payload: { type: "user_message", message: '<subagent_notification>\n{"agent_path":"child","status":{"completed":"done"},"kind":"subagent"}' }
  },
  {
    type: "user_message",
    timestamp: "2026-08-13T05:07:00.000Z",
    payload: { text: "<environment_context>\n<cwd>C:\\work</cwd>\n</environment_context>" }
  }
];
const protocolFile = jsonlFile(protocolRecords, "rollout-protocols.jsonl");
const protocolPrompts = await readBrowserThreadPrompts(
  promptWorkspace("thread-protocols", protocolFile),
  "thread-protocols"
);
assert.equal(protocolPrompts.promptCount, 11);
assert.equal(protocolPrompts.purePromptCount, 7);
assert.equal(protocolPrompts.visiblePromptCount, 7);
assert.deepEqual(protocolPrompts.sourceCounts, {
  user: 7,
  automation: 1,
  delegation: 1,
  subagent: 1,
  internal: 1
});
assert.deepEqual(
  protocolPrompts.prompts.map((prompt) => prompt.protocol),
  [
    "user_message",
    "event_msg",
    "user_message",
    "response_item",
    "response_item",
    "user_message",
    "event_msg",
    "user_message",
    "response_item",
    "event_msg",
    "user_message"
  ]
);

const reverseFile = jsonlFile([
  { type: "user_message", timestamp: "2026-08-13T08:00:00.000Z", payload: { text: "oldest prompt" } },
  { type: "user_message", timestamp: "2026-08-13T08:01:00.000Z", payload: { text: "middle prompt" } },
  { type: "user_message", timestamp: "2026-08-13T08:02:00.000Z", payload: { text: "newest prompt" } }
], "rollout-reverse.jsonl");
const reverseWorkspace = promptWorkspace("thread-reverse", reverseFile);
const newestPage = await readBrowserThreadPrompts(reverseWorkspace, "thread-reverse", {
  order: "desc",
  scope: "pure",
  limit: 2
});
assert.equal(newestPage.order, "desc");
assert.deepEqual(newestPage.prompts.map((prompt) => prompt.pureText), ["newest prompt", "middle prompt"]);
assert.equal(newestPage.hasMore, true);
assert.ok(newestPage.nextCursor);
assert.ok(newestPage.prompts.every((prompt) => prompt.ordinalExact === false));
const olderPage = await readBrowserThreadPrompts(reverseWorkspace, "thread-reverse", {
  order: "desc",
  scope: "pure",
  limit: 2,
  cursor: newestPage.nextCursor
});
assert.deepEqual(olderPage.prompts.map((prompt) => prompt.pureText), ["oldest prompt"]);
assert.equal(olderPage.hasMore, false);
const middleContext = await readBrowserThreadPromptContext(reverseWorkspace, "thread-reverse", {
  anchor: newestPage.prompts[1],
  scope: "pure",
  search: "middle",
  before: 1,
  after: 1
});
assert.deepEqual(middleContext.prompts.map((prompt) => prompt.pureText), ["oldest prompt", "middle prompt", "newest prompt"]);
assert.equal(middleContext.anchorOffset, 1);

const sparseReverseFile = jsonlFile([
  { type: "user_message", timestamp: "2026-08-13T07:00:00.000Z", payload: { text: "prompt at reverse scan boundary" } },
  ...Array.from({ length: 9_999 }, (_, index) => ({
    type: "event_msg",
    timestamp: "2026-08-13T07:01:00.000Z",
    payload: { type: "status", message: `status-${index}` }
  }))
], "rollout-sparse-reverse.jsonl");
const sparseReverseWorkspace = promptWorkspace("thread-sparse-reverse", sparseReverseFile);
const sparseFirstPage = await readBrowserThreadPrompts(sparseReverseWorkspace, "thread-sparse-reverse", {
  order: "desc",
  scope: "pure",
  limit: 2
});
assert.deepEqual(sparseFirstPage.prompts, []);
assert.equal(sparseFirstPage.hasMore, true);
assert.ok(sparseFirstPage.nextCursor);
const sparseSecondPage = await readBrowserThreadPrompts(sparseReverseWorkspace, "thread-sparse-reverse", {
  order: "desc",
  scope: "pure",
  limit: 2,
  cursor: sparseFirstPage.nextCursor
});
assert.deepEqual(sparseSecondPage.prompts.map((prompt) => prompt.pureText), ["prompt at reverse scan boundary"]);
assert.equal(sparseSecondPage.hasMore, false);
assert.deepEqual(
  protocolPrompts.prompts.slice(0, 7).map((prompt) => prompt.text),
  [
    "mirrored user input",
    "legacy event-only input",
    "top-level string payload",
    "intentionally repeated input",
    "intentionally repeated input",
    "same text sent again later",
    "same text sent again later"
  ]
);
assert.deepEqual(
  protocolPrompts.prompts.slice(7).map((prompt) => [prompt.sourceType, prompt.visibleByDefault, prompt.hasPureText]),
  [
    ["automation", false, false],
    ["delegation", false, false],
    ["subagent", false, false],
    ["internal", false, false]
  ]
);

const attachmentPrompt = [
  "# Files mentioned by the user:",
  "",
  "![attachment](data:image/png;base64,",
  "A".repeat(9 * 1024 * 1024),
  ")",
  "",
  "## My request:",
  "recover the user text after the attachment"
].join("\n");
const oversizedAttachmentFile = jsonlFile([{
  type: "response_item",
  timestamp: "2026-08-13T06:00:00.000Z",
  payload: { type: "message", role: "user", content: [{ type: "input_text", text: attachmentPrompt }] }
}], "rollout-oversized-attachment.jsonl");
const oversizedAttachmentPrompts = await readBrowserThreadPrompts(
  promptWorkspace("thread-oversized-attachment", oversizedAttachmentFile),
  "thread-oversized-attachment"
);
assert.equal(oversizedAttachmentPrompts.promptCount, 1);
assert.equal(oversizedAttachmentPrompts.aggregationExact, false);
assert.equal(oversizedAttachmentPrompts.oversizedRecords, 1);
assert.equal(oversizedAttachmentPrompts.prompts[0].protocol, "response_item");
assert.equal(oversizedAttachmentPrompts.prompts[0].textTruncated, false);
assert.equal(oversizedAttachmentPrompts.prompts[0].pureText, "recover the user text after the attachment");
assert.ok(!oversizedAttachmentPrompts.prompts[0].text.includes("A".repeat(1_024)));
assert.ok(!oversizedAttachmentPrompts.prompts[0].text.includes("base64"));

const oversizedTextFile = jsonlFile([{
  type: "user_message",
  timestamp: "2026-08-13T07:00:00.000Z",
  payload: { text: `bounded prompt start\n${"Z".repeat(9 * 1024 * 1024)}\nbounded prompt end` }
}], "rollout-oversized-text.jsonl");
const oversizedTextPrompts = await readBrowserThreadPrompts(
  promptWorkspace("thread-oversized-text", oversizedTextFile),
  "thread-oversized-text"
);
assert.equal(oversizedTextPrompts.promptCount, 1);
assert.equal(oversizedTextPrompts.prompts[0].textTruncated, true);
assert.ok(oversizedTextPrompts.prompts[0].text.startsWith("bounded prompt start"));
assert.ok(oversizedTextPrompts.prompts[0].text.endsWith("[Browser folder mode truncated this prompt text.]"));
assert.ok(oversizedTextPrompts.prompts[0].text.length <= 256 * 1024 + 64);
assert.ok(!oversizedTextPrompts.prompts[0].text.includes("bounded prompt end"));

for (const [name, file, search, expected] of [
  ["attachment", oversizedAttachmentFile, "recover the user text", oversizedAttachmentPrompts],
  ["text", oversizedTextFile, "bounded prompt start", oversizedTextPrompts]
]) {
  const threadId = `oversized-search-${name}`;
  const workspace = promptWorkspace(threadId, file);
  const ascending = await readBrowserThreadPrompts(workspace, threadId, { order: "asc", scope: "pure", search });
  const descending = await readBrowserThreadPrompts(workspace, threadId, { order: "desc", scope: "pure", search });
  const comparable = (page) => page.prompts.map(({ byteOffset, pureText, textTruncated, protocol }) => ({ byteOffset, pureText, textTruncated, protocol }));
  assert.deepEqual(comparable(ascending), comparable(expected));
  assert.deepEqual(comparable(descending), comparable(ascending), `${name}: descending search must recover the same bounded text`);
  assert.equal(descending.matchCount, 1);
  assert.equal(descending.oversizedRecords, 1);
  assert.equal(descending.aggregationExact, false);
  assert.equal(descending.hasMore, false);
  assert.equal(descending.nextCursor, null);
}

const paddingBlock = new Blob(["P".repeat(1024 * 1024)]);
const recoveredText = 'needle "escaped" \\ path\n\u4e2d\u6587';
const oversizedRecordParts = [
  '{"type":"response_item","ignored":"',
  ...Array(9).fill(paddingBlock),
  '","payload":',
  JSON.stringify({ type: "message", role: "user", content: [{ type: "input_text", text: recoveredText }] }),
  '}'
];
const oldRecord = JSON.stringify({ type: "user_message", payload: { text: "needle oldest" } });
const newRecord = JSON.stringify({ type: "user_message", payload: { text: "needle newest" } });
// CRLF and an unterminated EOF record must preserve byte anchors in both orders.
const mixedFile = boundedPromptFile([oldRecord, "\r\n", ...oversizedRecordParts, "\r\n", newRecord], "oversized-pagination.jsonl");
const mixedWorkspace = promptWorkspace("oversized-pagination", mixedFile);
const orderedPages = {};
for (const order of ["asc", "desc"]) {
  const collected = [];
  const cursors = new Set();
  let cursor = null;
  let page;
  do {
    page = await readBrowserThreadPrompts(mixedWorkspace, "oversized-pagination", { order, scope: "pure", search: "needle", limit: 1, cursor });
    collected.push(...page.prompts);
    cursor = page.nextCursor;
    if (cursor) {
      assert.ok(!cursors.has(cursor), "pagination must advance across oversized records");
      cursors.add(cursor);
    }
    assert.ok(cursors.size <= 3, "one-record pages must terminate without duplicates");
  } while (cursor);
  assert.equal(page.matchCount, 3);
  assert.equal(page.oversizedRecords, 1);
  assert.equal(page.matchCountComplete, true);
  orderedPages[order] = collected;
}
const promptCoverage = (prompts) => prompts.map(({ byteOffset, pureText, protocol, textTruncated }) => ({ byteOffset, pureText, protocol, textTruncated: Boolean(textTruncated) }));
assert.deepEqual(promptCoverage(orderedPages.desc), promptCoverage([...orderedPages.asc].reverse()));
assert.deepEqual(orderedPages.asc.map((prompt) => prompt.pureText), ["needle oldest", recoveredText, "needle newest"]);
assert.equal(orderedPages.desc[1].byteOffset, Buffer.byteLength(oldRecord + "\r\n"));
const oversizedContext = await readBrowserThreadPromptContext(mixedWorkspace, "oversized-pagination", {
  anchor: orderedPages.desc[0], scope: "pure", search: "needle", before: 1, after: 0
});
assert.deepEqual(oversizedContext.prompts.map((prompt) => prompt.pureText), [recoveredText, "needle newest"]);
assert.equal(oversizedContext.hasEarlier, true);

// One record may exceed the page budget; consume it once, then defer older records.
const budgetFile = boundedPromptFile([
  oldRecord, "\n", '{"type":"user_message","ignored":"', ...Array(33).fill(paddingBlock),
  '","payload":{"text":"needle over budget"}}'
], "oversized-budget.jsonl");
const budgetWorkspace = promptWorkspace("oversized-budget", budgetFile);
const budgetPage = await readBrowserThreadPrompts(budgetWorkspace, "oversized-budget", { order: "desc", scope: "pure", search: "needle" });
assert.deepEqual(budgetPage.prompts.map((prompt) => prompt.pureText), ["needle over budget"]);
assert.equal(budgetPage.hasMore, true);
assert.ok(budgetPage.nextCursor);
const afterBudget = await readBrowserThreadPrompts(budgetWorkspace, "oversized-budget", { order: "desc", scope: "pure", search: "needle", cursor: budgetPage.nextCursor });
assert.deepEqual(afterBudget.prompts.map((prompt) => prompt.pureText), ["needle oldest"]);
assert.equal(afterBudget.hasMore, false);
assert.equal(afterBudget.oversizedRecords, 1);

const cancelledFile = boundedPromptFile(oversizedRecordParts, "oversized-cancel.jsonl");
const cancellation = new AbortController();
const cancelledSlice = cancelledFile.slice.bind(cancelledFile);
let firstChunkReads = 0;
cancelledFile.slice = (start, end, contentType) => {
  if (start === 0 && ++firstChunkReads === 2) cancellation.abort();
  return cancelledSlice(start, end, contentType);
};
await assert.rejects(
  readBrowserThreadPrompts(promptWorkspace("oversized-cancel", cancelledFile), "oversized-cancel", { order: "desc", search: "needle", signal: cancellation.signal }),
  { name: "AbortError" }
);
assert.equal(firstChunkReads, 2, "abort must interrupt the forward recovery pass");

console.log("browser home streaming tests passed");
